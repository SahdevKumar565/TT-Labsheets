#include <stdio.h>
struct D{union{int i;float f;}u;char t;};
struct D g(){struct D d;d.u.i=7;d.t='i';return d;}
int main(){
  struct D d=g();
  printf("%c %d\n",d.t,d.u.i);
}