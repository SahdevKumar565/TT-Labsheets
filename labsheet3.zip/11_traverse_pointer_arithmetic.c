#include <stdio.h>
void tr(int*p,int n){for(int i=0;i<n;i++)printf("%d ",*(p+i));}
int main(){
  int a[]={4,5,6};
  tr(a,3);
}