s = "madam"
print("Palindrome" if s == s[::-1] else "Not Palindrome")
