#include <stdio.h>
int interp(int *a,int n,int x,int *s){int l=0,r=n-1;while(l<=r&&x>=a[l]&&x<=a[r]){(*s)++;
if(a[r]==a[l]){if(a[l]==x) return l;else break;}int pos=l+(double)(r-l)*(x-a[l])/(a[r]-a[l]);
if(a[pos]==x) return pos;if(a[pos]<x) l=pos+1; else r=pos-1;}return -1;}
int binary(int *a,int n,int x,int *s){int l=0,r=n-1;while(l<=r){(*s)++;int m=(l+r)/2;if(a[m]==x) return m;
if(a[m]<x) l=m+1; else r=m-1;}return -1;}
int main(){int n=10,a[10];for(int i=0;i<n;i++) a[i]=i+1;int x;scanf("%d",&x);int s1=0,s2=0;
interp(a,n,x,&s1);binary(a,n,x,&s2);printf("interp_steps=%d binary_steps=%d\n",s1,s2);}