#include <stdio.h>
struct P{int a,b;}p={8,2},*q=&p;
int main(){
  printf("%d %d %d %.1f\n",
    q->a+q->b,q->a-q->b,q->a*q->b,(float)q->a/q->b);
}