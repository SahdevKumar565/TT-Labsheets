#include <stdio.h>
#include <stdlib.h>
struct B{char t[20],a[20];float p;}*b;
int main(){
  b=malloc(5*sizeof* b);
  for(int i=0;i<5;i++)
    scanf("%s %s %f",b[i].t,b[i].a,&b[i].p);
  for(int i=0;i<5;i++)
    printf("%s %s %.1f\n",b[i].t,b[i].a,b[i].p);
}