#include <stdio.h>
union U{int i;float f;}u;
int main(){
  u.i=5; printf("%d\n",u.i);
  u.f=2.5; printf("%.1f\n",u.f);
}