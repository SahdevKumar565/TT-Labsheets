#include <stdio.h>
int main(){
  int a=1,b=2,*p=&a,*q=&b,t=*p;
  *p=*q;*q=t;
  printf("%d %d\n",a,b);
}