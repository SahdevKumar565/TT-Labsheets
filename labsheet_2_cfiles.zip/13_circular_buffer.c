#include <stdio.h>
#define N 5
int buf[N],head=0,count=0;
void push(int v){buf[(head+count)%N]=v;if(count<N) count++;else head=(head+1)%N;}
void show(){for(int i=0;i<count;i++) printf("%d ",buf[(head+i)%N]);printf("\n");}
int main(){for(int i=1;i<=7;i++){push(i);show();}}