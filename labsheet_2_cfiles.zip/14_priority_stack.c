#include <stdio.h>
typedef struct{int id,p;}T;T st[10];int top=-1;
void push(int id,int p){st[++top]=(T){id,p};}
void pop(){if(top==-1){printf("empty\n");return;}int idx=0;for(int i=1;i<=top;i++) if(st[i].p>st[idx].p) idx=i;
printf("exec %d\n",st[idx].id);for(int i=idx;i<top;i++) st[i]=st[i+1];top--;}
int main(){push(1,2);push(2,5);push(3,3);pop();pop();pop();}