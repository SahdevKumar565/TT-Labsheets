import collections
s = "hello world"
print(collections.Counter(s))
