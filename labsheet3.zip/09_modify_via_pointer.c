#include <stdio.h>
void inc(int*p){*p+=10;}
int main(){
  int v=5;
  inc(&v);
  printf("%d\n",v);
}