N = int(input("Enter N: "))
for i in range(N):
    print(i**2)
