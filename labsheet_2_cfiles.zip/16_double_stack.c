#include <stdio.h>
#define M 10
int a[M],t1=-1,t2=M;
void p1(int x){if(t1+1==t2) printf("ov\n");else a[++t1]=x;}
void p2(int x){if(t2-1==t1) printf("ov\n");else a[--t2]=x;}
void pop1(){if(t1==-1) printf("u1\n");else printf("%d\n",a[t1--]);}
void pop2(){if(t2==M) printf("u2\n");else printf("%d\n",a[t2++]);}
int main(){p1(10);p1(20);p2(100);p2(200);pop1();pop2();pop1();pop2();}