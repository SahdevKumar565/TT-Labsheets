#include <stdio.h>
struct P{int x;char*n;}p={9,"Hi"};
int main(){
  struct P*q=&p;
  printf("%d %s\n",q->x,q->n);
}