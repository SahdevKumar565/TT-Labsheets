#include <stdio.h>
int main(){int n;scanf("%d",&n);int a[n],b[n];for(int i=0;i<n;i++){scanf("%d",&a[i]);b[i]=a[i];}
int passes=0;for(int i=0;i<n-1;i++){for(int j=0;j<n-1-i;j++) if(a[j]>a[j+1]){int t=a[j];a[j]=a[j+1];a[j+1]=t;}passes++;}
printf("normal_passes=%d\n",passes);
passes=0;for(int i=0;i<n-1;i++){int s=0;for(int j=0;j<n-1-i;j++) if(b[j]>b[j+1]){int t=b[j];b[j]=b[j+1];b[j+1]=t;s=1;}passes++;if(!s) break;}
printf("opt_passes=%d\n",passes);}