print("Python", "is", "fun!")
