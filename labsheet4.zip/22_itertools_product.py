import itertools
list1, list2 = [1, 2], ['a', 'b']
print(list(itertools.product(list1, list2)))
