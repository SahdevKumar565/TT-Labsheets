#include <stdio.h>
int mx(int a,int b){return a>b?a:b;}
int main(){printf("%d\n",mx(3,7));}