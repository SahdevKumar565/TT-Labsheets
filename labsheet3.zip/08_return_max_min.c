#include <stdio.h>
void mm(int a,int b,int*mx,int*mn){
  if(a>b)*mx=a,*mn=b;else*mx=b,*mn=a;
}
int main(){
  int mxv,mnv;
  mm(5,8,&mxv,&mnv);
  printf("%d %d\n",mxv,mnv);
}