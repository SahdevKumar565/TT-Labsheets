num = int(input("Enter a number: "))
print("Even" if num % 2 == 0 else "Odd")
