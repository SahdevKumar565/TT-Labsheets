#include <stdio.h>
struct E{int id;char*n;float s;}e[3]={{
 1,"A",10},{2,"B",20},{3,"C",30}};
int main(){
  for(int i=0;i<3;i++)
    printf("%d %s %.1f\n",e[i].id,e[i].n,e[i].s);
}