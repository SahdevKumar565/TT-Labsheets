#include <stdio.h>
typedef struct{int id,val;} Item;
int main(){Item a[]={{1,50},{2,70},{3,70},{4,60}};int n=4;
for(int i=0;i<n;i++) printf("%d:%d ",a[i].id,a[i].val);printf("\n");
for(int i=0;i<n-1;i++){int m=i;for(int j=i+1;j<n;j++) if(a[j].val<a[m].val) m=j;Item t=a[i];a[i]=a[m];a[m]=t;}
for(int i=0;i<n;i++) printf("%d:%d ",a[i].id,a[i].val);printf("\n");}