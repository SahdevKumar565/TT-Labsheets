t = (1, 2, 3)
print(t)
# t[0] = 5  # ❌ Error (immutability)
