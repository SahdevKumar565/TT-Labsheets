#include <stdio.h>
#include <stdlib.h>
int main(){
  int r=2,c=3,**a=malloc(r*sizeof* a);
  for(int i=0;i<r;i++){
    a[i]=malloc(c*sizeof* *a);
    for(int j=0;j<c;j++) a[i][j]=i*c+j+1;
  }
  for(int i=0;i<r;i++){
    for(int j=0;j<c;j++) printf("%d ",a[i][j]);
    printf("\n"); free(a[i]);
  }
  free(a);
}