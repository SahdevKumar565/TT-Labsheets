import re
email = "test@example.com"
pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
print("Valid" if re.match(pattern, email) else "Invalid")
