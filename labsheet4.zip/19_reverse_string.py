s = "python"
print(s[::-1])
