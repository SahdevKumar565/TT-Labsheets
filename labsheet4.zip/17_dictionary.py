d = {"name": "Alice", "age": 20}
d["city"] = "Delhi"
print(d)
print(d["name"])
