#include <stdio.h>
#define MAX 5
int s[MAX],top=-1;void push(int v){if(top==MAX-1) printf("overflow\n");else s[++top]=v;}
void pop(){if(top==-1) printf("underflow\n");else printf("%d\n",s[top--]);}
int main(){push(10);push(20);pop();pop();pop();}