s = "programming"
vowels = "aeiouAEIOU"
count = sum(1 for c in s if c in vowels)
print("Vowels:", count)
