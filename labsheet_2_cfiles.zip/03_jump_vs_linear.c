#include <stdio.h>
#include <math.h>
int linear(int *a,int n,int x){for(int i=0;i<n;i++) if(a[i]==x) return i;return -1;}
int jump(int *a,int n,int x){int step=sqrt(n),prev=0;while(prev<n&&a[prev]<x){prev+=step;if(prev>=n)break;}
int start=prev-step;if(start<0)start=0;for(int i=start;i<n&&i<=prev;i++) if(a[i]==x) return i;return -1;}
int main(){int n,x;scanf("%d",&n);int a[n];for(int i=0;i<n;i++) scanf("%d",&a[i]);scanf("%d",&x);
printf("linear=%d jump=%d\n",linear(a,n,x),jump(a,n,x));}