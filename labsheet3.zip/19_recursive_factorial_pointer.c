#include <stdio.h>
void f(int n,int*r){
  if(n==1)*r=1;
  else{f(n-1,r);*r*=n;}
}
int main(){
  int r;
  f(5,&r);
  printf("%d\n",r);
}