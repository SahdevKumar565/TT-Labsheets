#include <stdio.h>
#include <stdlib.h>
int main(){
  char*s[5];
  for(int i=0;i<5;i++){s[i]=malloc(10);scanf("%s",s[i]);}
  for(int i=0;i<5;i++)printf("%s\n",s[i]);
}