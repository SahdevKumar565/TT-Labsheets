#include <stdio.h>
void sw(int*a,int*b){int t=*a;*a=*b;*b=t;}
int main(){
  int x=1,y=2;
  sw(&x,&y);
  printf("%d %d\n",x,y);
}