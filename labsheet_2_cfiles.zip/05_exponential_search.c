#include <stdio.h>
int bsearch(int *a,int l,int r,int x){while(l<=r){int m=(l+r)/2;if(a[m]==x) return m;
if(a[m]<x) l=m+1; else r=m-1;}return -1;}
int expsearch(int *a,int n,int x){if(n==0) return -1;if(a[0]==x) return 0;int i=1;
while(i<n&&a[i]<=x) i*=2;return bsearch(a,i/2,(i<n?i:n-1),x);}
int main(){int n;scanf("%d",&n);int a[n];for(int i=0;i<n;i++) scanf("%d",&a[i]);
int x;scanf("%d",&x);printf("%d\n",expsearch(a,n,x));}