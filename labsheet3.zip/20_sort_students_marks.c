#include <stdio.h>
struct S{name[20];int m;}s[3]={{
  "A",5},{"B",9},{"C",3}};
int main(){
  for(int i=0;i<3;i++)
    for(int j=i+1;j<3;j++)
      if(s[i].m<s[j].m){
        struct S t=s[i];s[i]=s[j];s[j]=t;
      }
  for(int i=0;i<3;i++)
    printf("%s %d\n",s[i].name,s[i].m);
}