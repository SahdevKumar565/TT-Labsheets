#include <stdio.h>
int s(int a[][3],int r){int t=0;
  for(int i=0;i<r;i++)
    for(int j=0;j<3;j++) t+=a[i][j];
  return t;
}
int main(){
  int m[2][3]={{1,2,3},{4,5,6}};
  printf("%d\n",s(m,2));
}