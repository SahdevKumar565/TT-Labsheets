#include <stdio.h>
#include <string.h>
#define MAX 5
char hist[MAX][128];int top=-1;
void save(const char*s){if(top<MAX-1) strcpy(hist[++top],s);}
void undo(){if(top==-1) printf("none\n");else printf("undo:%s\n",hist[top--]);}
int main(){save("one");save("two");save("three");undo();undo();undo();undo();}