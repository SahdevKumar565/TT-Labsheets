lst = [1, 2, 3]
lst.append(4)
lst.insert(1, 5)
lst.remove(2)
lst.sort()
print(lst)
