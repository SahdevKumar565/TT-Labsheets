#include <stdio.h>
void pr(int*a,int n){for(int i=0;i<n;i++)printf("%d ",a[i]);}
int main(){
  int a[]={1,2,3};
  pr(a,3);
}