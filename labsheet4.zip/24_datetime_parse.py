import datetime
date_str = "2025-09-28"
dt = datetime.datetime.strptime(date_str, "%Y-%m-%d")
print(dt.strftime("%d-%m-%Y"))
