#include <stdio.h>
int ai(int a,int b){return a+b;}
float af(float a,float b){return a+b;}
int main(){
  int (*f1)(int,int)=ai;
  float (*f2)(float,float)=af;
  printf("%d %.1f\n",f1(1,2),f2(1.5,2.5));
}