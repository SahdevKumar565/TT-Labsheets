#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct N{char u[64];struct N*next;}N;N*top=NULL;
void push(const char*s){N*n=malloc(sizeof *n);strcpy(n->u,s);n->next=top;top=n;printf("V:%s\n",s);}
void pop(){if(!top){printf("no history\n");return;}printf("B:%s\n",top->u);N*t=top;top=top->next;free(t);}
int main(){push("google");push("yt");pop();pop();pop();}